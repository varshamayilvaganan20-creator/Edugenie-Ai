# EduGenie Project – Template Mapping

This folder combines the supplied Project Templates archive with the supplied EduGenie source project.

## Source project
The EduGenie ZIP contains a FastAPI application with:
- app/main.py
- app/config.py
- app/schemas/models.py
- app/services/ (Gemini service, Q&A, explanation, quiz, summary, learning path)
- templates/index.html
- static/style.css and static/app.js
- tests/test_api.py
- requirements and Docker configuration

## Documentation phases
1. Ideation Phase
2. Requirement Analysis
3. Project Design Phase
4. Project Planning Phase
5. Project Development Phase
6. Project Documentation
7. Project Demonstration

The original template files are retained in their corresponding phase folders. The EduGenie source code is placed under:
`05 Project Development Phase/Source Code/`

## Project basis
The supplied EduGenie project document describes Q&A, simplified explanations, quiz generation, summaries, and personalized learning recommendations, with FastAPI as the backend and an HTML/CSS frontend.
